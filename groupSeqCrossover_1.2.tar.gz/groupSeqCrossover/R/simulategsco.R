simulategsco <- function(D = 4, L = 2, n = 12, f = c(0.7678445, 2.0358556),
                         e = c(2.879135, 2.035856), theta = 0,
                         sigma.e = sqrt(6.51), sequence.type = "williams",
                         replicates = 10000, REML = TRUE, adjust = TRUE,
                         mu.0 = 0, pi = rep(0, D - 1), sigma.b = sqrt(10.12),
                         parallel = TRUE, cpus = 8){

  ##### ERROR CHECKING ########################################################

  if ((D%%1 != 0) | (D < 2)){
    stop("D must be a whole number greater than or equal to 2.")
  }
  if ((L%%1 != 0) | (L < 1)){
    stop("L must be a whole number greater than or equal to 1.")
  }
  if ((n%%1 != 0) | (n < 1)){
    stop("n must be a whole number greater than or equal to 1.")
  }
  if (!is.vector(f) | (length(f) != L)){
    stop("f must be a vector of length L.")
  }
  if (!is.vector(e) | (length(e) != L)){
    stop("e must be a vector of length L.")
  }
  if (any(f > e)){
    stop("The efficacy boundary at each stage must be greater than or equal to the corresponding futility boudnary.")
  }
  if (!is.vector(theta)){
    stop("theta must be a vector.")
  }
  if (sigma.e <= 0){
    stop("Within person standard deviation sigma.e must be strictly positive.")
  }
  if (!(sequence.type %in% c("latin", "williams"))){
    stop("sequence.type must be set to \"latin\" or \"williams\".")
  }
  if ((replicates%%1 != 0) | (replicates < 1)){
    stop("replicates must be a whole number greater than or equal to 1.")
  }
  if (!is.logical(REML)){
    stop("REML must be logical.")
  }
  if (!is.logical(adjust)){
    stop("adjust must be logical.")
  }
  if (!is.numeric(mu.0)){
    stop("mu.0 must be numeric.")
  }
  if (!is.vector(pi) | (length(pi) != D - 1)){
    stop("pi must be a vector of length D - 1.")
  }
  if (sigma.b <= 0){
    stop("Between person standard deviation sigma.b must be strictly positive.")
  }
  if (!is.logical(parallel)){
    stop("parallel must be set to TRUE or FALSE.")
  }
  if ((cpus%%1 != 0) | (cpus < 1)){
    stop("cpus must be a whole number greater than or equal to 1.")
  }

  ##### FUNCTION INITIALISATION ###############################################

  individualGSCO <- function(D, L, n, f, e, mu.0, tau, sigma.e, sigma.b, pi,
                             sequences, Sigmas, REML, adjust){
    drugs.rem  <- 0:(D - 1)
    decision   <- numeric(D - 1)
    each.stage <- numeric(L)
    response   <- NULL
    period     <- NULL
    treatment  <- NULL
    individual <- NULL
    pi         <- c(0, pi)
    tau        <- c(0, tau)
    for (l in 1:L){
      each.stage[l]   <- length(drugs.rem)
      sequences.l     <- sequences[[length(drugs.rem)]]
      switches        <- list()
      for (d in 1:length(drugs.rem)){
        switches[[d]] <- which(sequences.l == d - 1)
      }
      for (d in 1:length(drugs.rem)){
        sequences.l[switches[[d]]] <- drugs.rem[d]
      }

      period         <- c(period, rep(1:length(drugs.rem), n))
      treatment.l    <- rep(as.vector(t(sequences.l)), n/nrow(sequences.l))
      treatment      <- c(treatment, treatment.l)
      individual.l   <- NULL
      for (i in 1:n){
        individual.l <- c(individual.l, rep(i + (l - 1)*n, length(drugs.rem)))
      }
      individual     <- c(individual, individual.l)

      mean.l         <- numeric(n*length(drugs.rem))
      for (i in 1:n){
        for (j in 1:length(drugs.rem)){
          mean.l[(i - 1)*length(drugs.rem) + j] <- mu.0 + pi[j] +
            tau[treatment.l[(i - 1)*length(drugs.rem) + j] + 1]
        }
      }
      response.l     <- rmvnorm(1, mean = mean.l, sigma = Sigmas[[length(drugs.rem)]])
      response       <- c(response, response.l)

      df.analysis        <- data.frame(Response = response,
                                       Period = factor(period, levels = 1:D),
                                       Treatment = factor(treatment, levels = 0:(D - 1)),
                                       Individual = factor(individual, unique(individual)))
      interim.analysis   <- lmer(Response ~ Period + Treatment + (1|Individual),
                                 data = df.analysis, REML = REML)
      beta.hat           <- fixef(interim.analysis)
      tau.hat            <- beta.hat[(D + 1):(2*D - 1)]
      I.hat              <- 1/diag(as.matrix(vcov(interim.analysis)))[(D + 1):(2*D - 1)]
      Z.hat              <- tau.hat*sqrt(I.hat)
      if (adjust == TRUE){
        DF.l <- n*sum(each.stage) - l*n  - 2*(D - 1)
        f[l] <- qt(pnorm(f[l], lower.tail = FALSE), lower.tail = FALSE, df = DF.l)
        e[l] <- qt(pnorm(e[l], lower.tail = FALSE), lower.tail = FALSE, df = DF.l)
      }
      new.drugs.rem     <- NULL
      for (d in drugs.rem[-1]){
        if (Z.hat[d] <= f[l]){
          decision[d]   <- 0
        } else if (Z.hat[d] > e[l]){
          decision[d]   <- 1
        } else if ((Z.hat[d] > f[l]) && (Z.hat[d] <= e[l])){
          new.drugs.rem <- c(new.drugs.rem, d)
        }
      }
      drugs.rem         <- c(0, new.drugs.rem)
      if (length(drugs.rem) == 1){
        break
      }
    }
    N   <- n*max(which(each.stage > 0))
    O   <- n*sum(each.stage)
    R.1 <- as.numeric(decision[1] == 1)
    R.A <- as.numeric(any(decision == 1))
    return(c(R.1, R.A, N, O))
  }

  wrapper <- function(rep){
    result <- individualGSCO(D, L, n, f, e, mu.0, rep(theta[i], D - 1),
                             sigma.e, sigma.b, pi, sequences, Sigmas, REML,
                             adjust)
    return(result)
  }

  ##### MAIN COMPUTATIONS #####################################################

  sequences              <- list()
  for (d in 2:D){
    if (sequence.type == "williams"){
      sequences[[d]]     <- williams(d) - 1
    } else {
      sequences.d        <- matrix(0, d, d)
      sequences.d[1, ]   <- 0:(d - 1)
      for (i in 2:d){
        sequences.d[i, ] <- c(sequences[i - 1, 2:d], sequences[i - 1, 1])
      }
      sequences[[d]]     <- sequences.d
    }
  }

  Sigmas        <- list()
  for (d in 2:D){
    Sigmas.d    <- matrix(0, d*n, d*n)
    Sigma.ind   <- matrix(sigma.b^2, d, d) + diag(sigma.e^2, d, d)
    for (i in 1:n){
      Sigmas.d[(1 + (i - 1)*d):(i*d), (1 + (i - 1)*d):(i*d)] <- Sigma.ind
    }
    Sigmas[[d]] <- Sigmas.d
  }

  performance <- matrix(0, nrow = length(theta), ncol = 4)
  sink("NULL")
  for (i in 1:length(theta)){
    suppressMessages(sfInit(parallel = parallel, cpus = cpus))
    suppressMessages(sfLibrary(mvtnorm))
    suppressMessages(sfLibrary(lme4))
    suppressMessages(sfLibrary(stats))
    sfExport("D", "L", "n", "f", "e", "mu.0", "theta",
             "sigma.e", "sigma.b", "pi", "sequences",
             "Sigmas", "REML", "adjust", "i", "individualGSCO")
    results <- sfLapply(1:replicates, wrapper)
    suppressMessages(sfStop())
    for (j in 1:replicates){
      performance[i, ] <- performance[i, ] + results[[j]]
    }
    performance[i, ]   <- performance[i, ]/replicates
  }
  sink()
  performance           <- cbind(theta, performance)
  colnames(performance) <- c("theta",
                             "P(Reject H_01 | theta)",
                             "P(Reject H_0d for some d | theta)",
                             "E(N | theta)",
                             "E(O | theta)")
  output <- list(adjust = adjust, cpus = cpus, D = D, e = e, f = f, L = L,
                 mu.0 = mu.0, n = n, parallel = parallel,
                 performance = performance, pi = pi, REML = REML,
                 replicates = replicates, sequence.type = sequence.type,
                 sigma.b = sigma.b, sigma.e = sigma.e, theta = theta)
  return(output)
}
